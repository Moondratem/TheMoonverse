using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] TMP_Text timerText;
    [SerializeField] GameObject merman;
    [SerializeField] GameObject zombie;
    [SerializeField] GameObject vampire;
    [SerializeField] GameObject player;

    int spawnCounter = 1;

    private void Update()
    {
        int seconds = (int)Time.time;
        timerText.text = "00:" + seconds;
    }

    void Start()
    {
        //For testing
        if(TitleManager.saveData == null)
        {
            TitleManager.saveData = new SaveData();
        }

        StartCoroutine(SpawnEnemiesCoroutine());
    }

    IEnumerator SpawnEnemiesCoroutine()
    {        
        SpawnEnemies(zombie, 5);
        yield return new WaitForSeconds(5f);
        SpawnEnemies(merman, 5, false);
        yield return new WaitForSeconds(5f);
        SpawnEnemies(vampire, 5);
        yield return new WaitForSeconds(5f);
        SpawnEnemies(merman, 5);
        SpawnEnemies(zombie, 5);
        yield return new WaitForSeconds(5f);
        SpawnEnemies(merman, 5);
        SpawnEnemies(zombie, 5);        
        SpawnEnemies(vampire, 5);        
        yield return new WaitForSeconds(5f);    

        while (true)
        {
            SpawnEnemies(merman, 10 * spawnCounter++);
            yield return new WaitForSeconds(10f);
        }
    }

    private void SpawnEnemies(GameObject enemyToSpawn, int numberofEnemies, bool isChasing = true)
    {
        for (int i = 0; i < numberofEnemies; i++)
        {
            Vector3 spawnPosition = UnityEngine.Random.insideUnitCircle.normalized * 8;
            spawnPosition += player.transform.position;
            GameObject go = Instantiate(enemyToSpawn, spawnPosition, Quaternion.identity);
            Enemy enemy = go.GetComponent<Enemy>();            
            enemy.isChasing = isChasing;
        }
    }
}
