using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Hold CTRL , Press K , Press D

public class PlayerCamera : MonoBehaviour
{
    [SerializeField] Transform target;

    private void Update()
    {
        //Make camera follow the player
        if (target == null)
        {
            return;
        }

        transform.position = new Vector3(target.position.x, target.position.y, -10);
    }
}
