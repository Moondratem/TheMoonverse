using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scythe : MonoBehaviour
{
    private void Start()
    {
        Destroy(gameObject, 3);
    }

    private void Update()
    {
        transform.position += transform.right * 5 * Time.deltaTime;            
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Enemy enemy = collision.GetComponent<Enemy>();
        if (enemy)
        {
            enemy.Damage(2);
            Destroy(gameObject);
        }
    }
}
