using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    [SerializeField] float speed = 1;
    [SerializeField] BaseWeapon[] weapons;
    
    SpriteRenderer spriteRenderer;
    Animator animator;

    [SerializeField] internal int playerMaxHP = 5;
    internal int playerHP;
    bool isInvincible;

    internal int currentExp;
    internal int expToLevel = 5;
    internal int currentLevel;

    internal Action<int, int> OnExpGained;

    private void Start()
    {
        weapons[0].LevelUp();

        playerHP = playerMaxHP;    

        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    internal void AddExp()
    {
        currentExp++;

        if(currentExp >= expToLevel)
        {
            currentExp -= expToLevel;
            currentLevel++;
            expToLevel += 5;

            weapons[UnityEngine.Random.Range(0, weapons.Length)].LevelUp();

            Time.timeScale = 0;
        }

        OnExpGained(currentExp, expToLevel);
    }

    internal void OnDamage()
    {                
        if(!isInvincible)
        {
            StartCoroutine(InvincibilityCoroutine());            
                        
            if (--playerHP <= 0)
            {
                //increase death count
                TitleManager.saveData.deathCount++;                
                SceneManager.LoadScene("Title");
            }
        }
    }

    IEnumerator InvincibilityCoroutine()
    {
        isInvincible = true;
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.5f);
        spriteRenderer.color = Color.white;
        isInvincible = false;
    }

    void Update()
    {        
        //Move
        float inputX = Input.GetAxis("Horizontal");
        float inputY = Input.GetAxis("Vertical");
        transform.position += new Vector3(inputX, inputY) * speed * Time.deltaTime;

        //Manual Attack        
        //weapon.SetActive(Input.GetKey(KeyCode.Z););

        //Flip Sprite
        if (inputX != 0)
        {
            transform.localScale = new Vector3(inputX > 0 ? -1f : 1, 1, 1);
        }
        
        //Running animation
        animator.SetBool("IsRunning", inputX != 0 || inputY != 0);
    }
}
